package com.mathmaniarobotics.steamnews;

public class NewsActivity {
    private static final String GUARDIAN_REQUEST_URL = "https://content.guardianapis.com/search?to-date=2021-02-24&q=robotics%20education&api-key=96dd1917-a8fb-4aba-84b9-326bb8b03092";
}

//This is not used in the app
